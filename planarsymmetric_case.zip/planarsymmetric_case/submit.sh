#!/bin/bash

#SBATCH -J capWav	 # Name of job
#SBATCH -n 64 		 # Number of cores - this must match decomposeParDict
#SBATCH -N 1             # How many nodes. For now, we typically want all cores on 1 machine
#SBATCH -p cpu64         # Name of partition to submit to
#SBATCH -o output.out  	 # Redirect output to this file.
#SBATCH -e errors.err 	 # Redirect error messages to this file

echo --number of cores chosen = $SLURM_NTASKS--
echo --alotted partition = $SLURM_JOB_PARTITION--
echo --alotted node list = $SLURM_JOB_NODELIST--
echo --alotted job ID = $SLURM_JOBID--
./Allclean
echo --previous solution and log files cleared--

sed -i '56d' ./system/parameters
echo "num_domain $SLURM_NTASKS; //num of domains=num of cores" >> ./system/parameters
echo --number of domains updated in parameters file--

echo --OpenFOAM START--
echo --start time--
date

# Commands to run simulation
./Allrun

rm -rf process*
echo --clearing individual processor data after reconstructPar--
echo --FINISHED--
echo --end time--
date
